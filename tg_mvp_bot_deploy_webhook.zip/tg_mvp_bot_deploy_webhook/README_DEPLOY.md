# Deploy (Webhook) — Render

## Быстрый план
1) Сделайте НОВЫЙ токен в @BotFather (/revoke → /token).
2) Создайте пустой репозиторий на GitHub и залейте файлы из этого архива.
3) На https://render.com → New → **Blueprint** → укажите ссылку на ваш репозиторий (файл `render.yaml` в корне).
4) На этапе создания сервиса задайте переменные окружения:
   - BOT_TOKEN — из BotFather
   - ADMIN_EMAIL — адрес администрации
   - SMTP_HOST / SMTP_PORT=587 / SMTP_USER / SMTP_PASS / FROM_EMAIL — SMTP провайдера
5) Дождитесь деплоя — Render даст адрес вида `https://<name>.onrender.com`.
6) В настройках сервиса на Render добавьте env `PUBLIC_URL=https://<name>.onrender.com` и **Redeploy** — при старте приложение само выставит webhook на `PUBLIC_URL/webhook/BOT_TOKEN`.
7) Напишите боту `/start` в Telegram.

## Проверка
- Откройте `https://<name>.onrender.com/` — должно отвечать `OK`.
- В логах Render увидите `Webhook set to ...`.
- Если бот молчит — проверьте корректность `PUBLIC_URL` и токена.

## Замечания
- Render Free может “усыплять” сервис при простое. При первом обращении он просыпается; Telegram сам ретраит доставку webhook-ивентов.
- Хотите без webhook — можно запустить версию с polling как background worker.
