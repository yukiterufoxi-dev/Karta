# app_webhook.py
"""
Aiohttp webhook server for aiogram v3 to run on Render/Railway/VPS.
- Exposes POST /webhook/{token}
- Sets Telegram webhook to https://<PUBLIC_URL>/webhook/<BOT_TOKEN> on startup
- Health check at GET /
Env vars: BOT_TOKEN, ADMIN_EMAIL, SMTP_*, FROM_EMAIL, PUBLIC_URL
"""
import os
import asyncio
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, Location, Update
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiogram.client.default import DefaultBotProperties
from dotenv import load_dotenv
import aiosmtplib

load_dotenv()

BOT_TOKEN = os.environ.get("BOT_TOKEN")
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL")
SMTP_HOST = os.environ.get("SMTP_HOST")
SMTP_PORT = int(os.environ.get("SMTP_PORT", 587))
SMTP_USER = os.environ.get("SMTP_USER")
SMTP_PASS = os.environ.get("SMTP_PASS")
FROM_EMAIL = os.environ.get("FROM_EMAIL", ADMIN_EMAIL)
PUBLIC_URL = os.environ.get("PUBLIC_URL")  # e.g. https://your-service.onrender.com

DATA_DIR = Path("data"); DATA_DIR.mkdir(exist_ok=True)
DB_PATH = Path("storage.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  username TEXT,
  description TEXT NOT NULL,
  photo_path TEXT NOT NULL,
  lat REAL,
  lon REAL,
  created_at TEXT NOT NULL,
  email_status TEXT NOT NULL
);
"""

def db_init():
    with closing(sqlite3.connect(DB_PATH)) as con:
        con.execute(SCHEMA)
        con.commit()

def db_add_report(user_id:int, username:str|None, description:str, photo_path:str, lat:float|None, lon:float|None, email_status:str):
    with closing(sqlite3.connect(DB_PATH)) as con:
        con.execute(
            "INSERT INTO reports(user_id, username, description, photo_path, lat, lon, created_at, email_status) VALUES(?,?,?,?,?,?,?,?)",
            (user_id, username, description, photo_path, lat, lon, datetime.utcnow().isoformat(), email_status),
        )
        con.commit()

def db_last_reports(user_id:int, limit:int=5):
    with closing(sqlite3.connect(DB_PATH)) as con:
        cur = con.execute("SELECT id, description, lat, lon, created_at, email_status FROM reports WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))
        return cur.fetchall()

class ReportFlow(StatesGroup):
    wait_photo = State()
    wait_description = State()
    wait_location = State()

@dataclass
class ReportDraft:
    photo_path: str | None = None
    description: str | None = None
    lat: float | None = None
    lon: float | None = None

async def send_email_with_attachment(subject:str, html_body:str, to_email:str, attachment_path:Path|None=None):
    msg = MIMEMultipart()
    msg["From"] = FROM_EMAIL
    msg["To"] = to_email
    msg["Subject"] = subject

    msg.attach(MIMEText(html_body, "html", _charset="utf-8"))

    if attachment_path and attachment_path.exists():
        with open(attachment_path, "rb") as f:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f"attachment; filename=\"{attachment_path.name}\"")
        msg.attach(part)

    try:
        await aiosmtplib.send(
            msg,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            start_tls=True,
            username=SMTP_USER,
            password=SMTP_PASS,
        )
        return "sent"
    except Exception as e:
        return f"error: {e.__class__.__name__}: {e}"

assert BOT_TOKEN, "BOT_TOKEN is required"
assert ADMIN_EMAIL, "ADMIN_EMAIL is required"

bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())

def main_kb():
    kb = ReplyKeyboardBuilder()
    kb.button(text="Отправить жалобу")
    kb.button(text="Мои заявки")
    kb.adjust(2)
    return kb.as_markup(resize_keyboard=True)

@dp.message(CommandStart())
async def start(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(
        "Здравствуйте! Я помогу отправить жалобу в администрацию.\n\n"
        "Нажмите <b>Отправить жалобу</b> и следуйте шагам.",
        reply_markup=main_kb(),
    )

@dp.message(F.text == "Мои заявки")
async def my_reports(m: Message):
    rows = db_last_reports(m.from_user.id, 10)
    if not rows:
        await m.answer("У вас пока нет заявок.")
        return
    lines = ["<b>Последние заявки</b>"]
    for rid, desc, lat, lon, created, status in rows:
        loc = f" (📍{lat:.5f},{lon:.5f})" if lat and lon else ""
        lines.append(f"#{rid} — {desc[:80]}{loc}\nСтатус отправки: <i>{status}</i>\nДата: {created}")
    await m.answer("\n\n".join(lines))

@dp.message(F.text == "Отправить жалобу")
async def start_report(m: Message, state: FSMContext):
    await state.set_state(ReportFlow.wait_photo)
    await state.update_data(draft=ReportDraft().__dict__)
    await m.answer("Пришлите <b>фото проблемы</b> одним сообщением (как фото, не как файл).")

@dp.message(ReportFlow.wait_photo, F.photo)
async def got_photo(m: Message, state: FSMContext):
    file = await bot.get_file(m.photo[-1].file_id)
    DATA_DIR.mkdir(exist_ok=True, parents=True)
    file_path = DATA_DIR / f"{m.from_user.id}_{file.file_unique_id}.jpg"
    await bot.download_file(file.file_path, destination=file_path)

    data = await state.get_data()
    draft = ReportDraft(**data.get("draft"))
    draft.photo_path = str(file_path)
    await state.update_data(draft=draft.__dict__)

    await state.set_state(ReportFlow.wait_description)
    await m.answer("Коротко опишите проблему (до 300 символов).")

@dp.message(ReportFlow.wait_photo)
async def expect_photo_hint(m: Message):
    await m.answer("Пожалуйста, отправьте фото (кнопка скрепки → Фото).")

@dp.message(ReportFlow.wait_description, F.text)
async def got_description(m: Message, state: FSMContext):
    text = m.text.strip()[:300]
    data = await state.get_data()
    draft = ReportDraft(**data.get("draft"))
    draft.description = text
    await state.update_data(draft=draft.__dict__)

    kb = ReplyKeyboardBuilder()
    kb.button(text="Отправить геопозицию", request_location=True)
    kb.button(text="Пропустить")
    kb.adjust(1,1)
    await state.set_state(ReportFlow.wait_location)
    await m.answer("Прикрепите геопозицию (или нажмите Пропустить).", reply_markup=kb.as_markup(resize_keyboard=True))

@dp.message(ReportFlow.wait_location, F.location)
async def got_location(m: Message, state: FSMContext):
    data = await state.get_data()
    draft = ReportDraft(**data.get("draft"))
    loc: Location = m.location
    draft.lat, draft.lon = loc.latitude, loc.longitude
    await state.update_data(draft=draft.__dict__)
    await finalize_and_send(m, state)

@dp.message(ReportFlow.wait_location, F.text.casefold() == "пропустить")
async def skip_location(m: Message, state: FSMContext):
    await finalize_and_send(m, state)

async def finalize_and_send(m: Message, state: FSMContext):
    data = await state.get_data()
    draft = ReportDraft(**data.get("draft"))

    subject = "Сообщение о нарушении благоустройства"
    place = f"\nКоординаты: {draft.lat:.5f}, {draft.lon:.5f}" if draft.lat and draft.lon else ""
    html = (
        f"<p>Добрый день! Направляю обращение гражданина.</p>"
        f"<p><b>Описание:</b> {draft.description}</p>"
        f"<p><b>Дата/время:</b> {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>"
        f"<p><b>Отправитель:</b> @{m.from_user.username or m.from_user.id}</p>"
        f"<p><b>Локация:</b> {('см. ниже' if place else 'не указана')}{place}</p>"
        f"<p>Фото во вложении.</p>"
    )

    status = await send_email_with_attachment(subject, html, ADMIN_EMAIL, Path(draft.photo_path))

    db_add_report(m.from_user.id, m.from_user.username, draft.description or "", draft.photo_path or "", draft.lat, draft.lon, status)

    await state.clear()
    await m.answer(
        "Спасибо! Обращение сформировано и отправлено: <b>" + ("успешно" if status == "sent" else status) + "</b>.\n"
        "Смотрите ваши заявки в меню <b>Мои заявки</b>.",
        reply_markup=main_kb(),
    )

# ---------- Aiohttp app & webhook ----------
async def on_startup(app: web.Application):
    db_init()
    # set webhook if PUBLIC_URL provided
    if PUBLIC_URL:
        from aiogram.methods import SetWebhook, DeleteWebhook
        webhook_url = PUBLIC_URL.rstrip("/") + f"/webhook/{BOT_TOKEN}"
        try:
            await bot(SetWebhook(url=webhook_url, drop_pending_updates=True))
            print("Webhook set to", webhook_url)
        except Exception as e:
            print("Failed to set webhook:", e)

async def on_shutdown(app: web.Application):
    await bot.session.close()

def create_app():
    app = web.Application()
    app.router.add_get("/", lambda request: web.Response(text="OK"))
    # webhook handler
    handler = SimpleRequestHandler(dispatcher=dp, bot=bot)
    handler.register(app, path=f"/webhook/{BOT_TOKEN}")
    setup_application(app, dp, bot=bot)
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
